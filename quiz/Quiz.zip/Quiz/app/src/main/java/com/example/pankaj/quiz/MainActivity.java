package com.example.pankaj.quiz;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
RadioGroup q1,q2;
Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        q1 = findViewById(R.id.q1);
        q2 = findViewById(R.id.q2);
        submit = findViewById(R.id.button);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int count =0;
                int s1 = q1.getCheckedRadioButtonId();
                if(s1==R.id.a1)
                    count++;
                int s2 = q2.getCheckedRadioButtonId();

                if (s2 == R.id.p1)
                    count++;
                Toast.makeText(MainActivity.this, "Score is "+count+"/2", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
