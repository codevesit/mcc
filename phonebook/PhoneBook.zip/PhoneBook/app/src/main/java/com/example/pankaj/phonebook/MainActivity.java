package com.example.pankaj.phonebook;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name,number;
    Button add,display,modify;
    DatabaseHandler databaseHandler;
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name =  findViewById(R.id.editText);
        number = findViewById(R.id.editText2);
        add = findViewById(R.id.button);
        display = findViewById(R.id.button2);
        tv = findViewById(R.id.textView);
        modify = findViewById(R.id.button3);
        databaseHandler =  new DatabaseHandler(this);
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ename = name.getText().toString();
                String enumber = number.getText().toString();
                if(ename.length()==0||enumber.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter proper details", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    databaseHandler.addContacts(ename,enumber);
                    String contacts = databaseHandler.getContacts();
                    tv.setText(contacts);
                }
            }
        });

        display.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String contacts = databaseHandler.getContacts();
                tv.setText(contacts);

            }
        });
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ename = name.getText().toString();
                String enumber = number.getText().toString();
                if(ename.length()==0||enumber.length()==0)
                {
                    Toast.makeText(MainActivity.this, "Enter proper details", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    databaseHandler.modifyContacts(ename,enumber);
                    String contacts = databaseHandler.getContacts();
                    tv.setText(contacts);
                }

            }
        });
    }

}
