package com.example.pankaj.phonebook;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by PANKAJ on 4/22/2018.
 */

public class DatabaseHandler extends SQLiteOpenHelper{
    SQLiteDatabase db;
    Context c;
    public DatabaseHandler(Context context) {
        super(context, "phonebook_db", null, 1);
        Log.d("DB","db opened");
        this.c=context;
        db = this.getWritableDatabase();

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db = sqLiteDatabase;
        db.execSQL("CREATE TABLE phone_book(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT)");
        Log.d("DB","table created");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db = sqLiteDatabase;
        db.execSQL("DROP TABLE IF exists phone_book");
        Log.d("DB","dropped");
        onCreate(db);
    }
    public  void addContacts(String name,String phone){
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        long rid = db.insert("phone_book",null,contentValues);
        if(rid<0)
        {
            Toast.makeText(c, "Insert issue", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(c, "1 contact inserted", Toast.LENGTH_SHORT).show();
        }
    }
    public  void modifyContacts(String name,String phone){
        ContentValues contentValues = new ContentValues();
        contentValues.put("name",name);
        contentValues.put("phone",phone);
        long rid = db.update("phone_book",contentValues,"phone="+phone,null);
        if(rid<0)
        {
            Toast.makeText(c, "Insert issue", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(c, "1 contact modified", Toast.LENGTH_SHORT).show();
        }
    }

    public String getContacts()
    {
        StringBuffer sb = new StringBuffer();
        Cursor cursor = db.rawQuery("SELECT * FROM phone_book",null);
        if(cursor.getCount() == 0)
        {
            Toast.makeText(c, "No Contacts", Toast.LENGTH_SHORT).show();
            return "";
        }
        else
        {
            cursor.moveToFirst();
            do {
                String name = cursor.getString(1);
                String phone = cursor.getString(2);
                sb.append(name + " "+phone+ "\n");

            }while (cursor.moveToNext());
            return  sb.toString();
        }
    }
}
